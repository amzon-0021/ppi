from distutils.core import setup

setup(name='line',
      version='1.0',
      description='line APIcore',
      author='amzon',
      url='http://www.python.org/sigs/distutils-sig/',
      py_modules = ['line'],
     )
